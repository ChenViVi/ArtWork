//File Name: server.c 
//Author: SongLee
#include<sys/types.h> 
#include<sys/socket.h> 
#include<unistd.h> 
#include<netinet/in.h> 
#include<arpa/inet.h> 
#include<stdio.h> 
#include<stdlib.h> 
#include<errno.h> 
#include<netdb.h> 
#include<stdarg.h> 
#include<string.h> 

#define SERVER_PORT 8000 
#define BUFFER_SIZE 1024 
#define FILE_NAME_MAX_SIZE 512 

int main() 
{ 
	/* ����UDP�׽ӿ� */
	struct sockaddr_in server_addr; 
	bzero(&server_addr, sizeof(server_addr)); 
	server_addr.sin_family = AF_INET; 
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY); 
	server_addr.sin_port = htons(SERVER_PORT); 

	/* ����socket */
	int server_socket_fd = socket(AF_INET, SOCK_DGRAM, 0); 
	if(server_socket_fd == -1) 
	{ 
		perror("Create Socket Failed:"); 
		exit(1); 
	} 

	/* ���׽ӿ� */
	if(-1 == (bind(server_socket_fd,(struct sockaddr*)&server_addr,sizeof(server_addr)))) 
	{ 
		perror("Server Bind Failed:"); 
		exit(1); 
	} 

	/* ���ݴ��� */
	while(1) 
	{  
		/* ����һ����ַ�����ڲ���ͻ��˵�ַ */
		struct sockaddr_in client_addr; 
		socklen_t client_addr_length = sizeof(client_addr); 

		/* �������� */
		char buffer[BUFFER_SIZE]; 
		bzero(buffer, BUFFER_SIZE); 
		if(recvfrom(server_socket_fd, buffer, BUFFER_SIZE,0,(struct sockaddr*)&client_addr, &client_addr_length) == -1) 
		{ 
			perror("Receive Data Failed:"); 
			exit(1); 
		} 

		/* ��buffer�п�����file_name */
		char file_name[FILE_NAME_MAX_SIZE+1]; 
		bzero(file_name,FILE_NAME_MAX_SIZE+1); 
		strncpy(file_name, buffer, strlen(buffer)>FILE_NAME_MAX_SIZE?FILE_NAME_MAX_SIZE:strlen(buffer)); 
		printf("%s\n", file_name); 
	} 
	close(server_socket_fd); 
	return 0; 
}
client�˴������£�
/*
   > File Name: client.c 
   > Author: SongLee 
 */
#include<sys/types.h> 
#include<sys/socket.h> 
#include<unistd.h> 
#include<netinet/in.h> 
#include<arpa/inet.h> 
#include<stdio.h> 
#include<stdlib.h> 
#include<errno.h> 
#include<netdb.h> 
#include<stdarg.h> 
#include<string.h> 

#define SERVER_PORT 8000 
#define BUFFER_SIZE 1024 
#define FILE_NAME_MAX_SIZE 512 

int main() 
{ 
	/* ����˵�ַ */
	struct sockaddr_in server_addr; 
	bzero(&server_addr, sizeof(server_addr)); 
	server_addr.sin_family = AF_INET; 
	server_addr.sin_addr.s_addr = inet_addr("127.0.0.1"); 
	server_addr.sin_port = htons(SERVER_PORT); 

	/* ����socket */
	int client_socket_fd = socket(AF_INET, SOCK_DGRAM, 0); 
	if(client_socket_fd < 0) 
	{ 
		perror("Create Socket Failed:"); 
		exit(1); 
	} 

	/* �����ļ����������� */
	char file_name[FILE_NAME_MAX_SIZE+1]; 
	bzero(file_name, FILE_NAME_MAX_SIZE+1); 
	printf("Please Input File Name On Server:\t"); 
	scanf("%s", file_name); 

	char buffer[BUFFER_SIZE]; 
	bzero(buffer, BUFFER_SIZE); 
	strncpy(buffer, file_name, strlen(file_name)>BUFFER_SIZE?BUFFER_SIZE:strlen(file_name)); 

	/* �����ļ��� */
	if(sendto(client_socket_fd, buffer, BUFFER_SIZE,0,(struct sockaddr*)&server_addr,sizeof(server_addr)) < 0) 
	{ 
		perror("Send File Name Failed:"); 
		exit(1); 
	} 

	close(client_socket_fd); 
	return 0; 
}
