package com.tencent.qcloud.presentation.viewfeatures;

/**
 * Created by admin on 16/3/1.
 */
public interface MvpView {

}
